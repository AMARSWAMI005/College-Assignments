#include <stdio.h>
int main()
{
int n;
printf("size of array : ");
scanf("%d",&n);
int a[n][n],b[n][n],i,j,k;
int c[n][n];
int *p,*q;
p=&a[0][0];
q=&b[0][0];
printf("enter ele of 1st");  
for(i=0;i<n;i++){
    for(j=0;j<n;j++){
        scanf("%d",(p+((i*3)+j)));
    }
    printf("\n");
}
printf("enter ele of 2nd");    
for(i=0;i<n;i++){
    for(j=0;j<n;j++){
        scanf("%d",(q+((i*3)+j)));
    }
} 
printf("\n");
for(i=0;i<n;i++){
    for(j=0;j<n;j++){
     printf(" %d ",*(p+((i*3)+j)));
    }  
        printf("\n");
}
printf("\n ");
for(i=0;i<n;i++){
    for(j=0;j<n;j++){
     printf(" %d ",*(q+((i*3)+j)));
    }
    printf("\n");
}
 printf("\n");
for(i=0;i<n;i++){
    for(j=0;j<n;j++)
c[i][j]=0;
    
}

for(i=0;i<n;i++){
    for(j=0;j<n;j++){
        for(k=0;k<n;k++){
        c[i][j]= c[i][j]+ *(p+((i*3)+k)) * *(q+((i*3)+k));
           
            
        }
            printf(" %d ",c[i][j]);
    }
      printf("\n");
}

    return 0;
} 